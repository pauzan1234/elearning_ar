<?php $__env->startSection('ketjudul'); ?>
DAFTAR
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Program Studi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">

    <?php $__empty_1 = true; $__currentLoopData = $prodiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('dosen.prodi', $prodi->id)); ?>"
           class="group block bg-white border border-line rounded-2xl p-5 hover:border-teal hover:shadow-md transition-all duration-200">
            <div class="w-11 h-11 rounded-xl bg-paper border border-line flex items-center justify-center text-xl mb-4 group-hover:bg-teal/10">
                🎓
            </div>
            <h3 class="font-display text-lg font-semibold text-ink mb-1">
                <?php echo e($prodi->nama_prodi); ?>

            </h3>
            <p class="text-sm text-ink/50 font-mono">
                Lihat dosen pengampu →
            </p>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-ink/50 col-span-full">Belum ada data program studi.</p>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\elearning_ar\resources\views/admin/dosen-pengampu.blade.php ENDPATH**/ ?>