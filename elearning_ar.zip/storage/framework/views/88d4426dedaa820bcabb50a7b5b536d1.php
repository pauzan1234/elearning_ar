<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <!-- Login Card -->
    <div class="bg-white rounded-2xl border border-[#DCE6F5] shadow-xl overflow-hidden">

        <!-- Header -->
        <div class="bg-[#0F2A4D] px-8 py-8 text-center">

            <!-- Logo -->
            <div class="w-11 h-11 mx-auto rounded-lg bg-[#F5F8FC]/10 border border-white/10 flex items-center justify-center">
                <span class="font-display text-xl font-semibold text-[#93C5FD]">
                    U
                </span>
            </div>

            <h1 class="mt-4 font-display text-2xl font-semibold text-white">
                Selamat datang kembali.
            </h1>

            <p class="mt-2 text-sm text-white/60">
                Masuk untuk melanjutkan aktivitas perkuliahanmu di
                E-Learning UNWIR. </p>

        </div>


        <!-- Form -->
        <div class="px-8 py-8">

            <!-- Session Status -->
            <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-5','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-5','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>





            <form method="POST" action="<?php echo e(route('login')); ?>">

                <?php echo csrf_field(); ?>


                <!-- Email -->
                <div>

                    <label
                        for="email"
                        class="block text-sm font-medium text-[#0F2A4D]">

                        Email

                    </label>

                    <input
                        id="email"
                        type="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        required
                        autofocus
                        autocomplete="username"
                        placeholder="Masukkan email aktif"
                        class="mt-2 block w-full rounded-xl border-[#DCE6F5] bg-[#F5F8FC]/50 px-4 py-3 text-sm text-[#0F2A4D] placeholder:text-[#0F2A4D]/35 shadow-sm transition focus:border-[#2563EB] focus:ring-[#2563EB]">

                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>

                </div>


                <!-- Password -->
                <div class="mt-5">

                    <label
                        for="password"
                        class="block text-sm font-medium text-[#0F2A4D]">

                        Password

                    </label>

                    <input
                        id="password"
                        type="password"
                        name="password"
                        required
                        autocomplete="current-password"
                        placeholder="Masukkan password"
                        class="mt-2 block w-full rounded-xl border-[#DCE6F5] bg-[#F5F8FC]/50 px-4 py-3 text-sm text-[#0F2A4D] placeholder:text-[#0F2A4D]/35 shadow-sm transition focus:border-[#2563EB] focus:ring-[#2563EB]">

                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>

                </div>


                <!-- Remember & Forgot Password -->
                <div class="mt-5 flex items-center justify-between">

                    <label class="flex items-center cursor-pointer">

                        <input
                            id="remember_me"
                            type="checkbox"
                            name="remember"
                            class="rounded border-[#DCE6F5] text-[#2563EB] shadow-sm focus:ring-[#2563EB]">

                        <span class="ml-2 text-sm text-[#0F2A4D]/60">
                            Ingat saya
                        </span>

                    </label>


                    <?php if(Route::has('password.request')): ?>

                    <a
                        href="<?php echo e(route('password.request')); ?>"
                        class="text-sm font-medium text-[#2563EB] hover:text-[#0F2A4D] transition-colors">

                        Lupa password?

                    </a>

                    <?php endif; ?>

                </div>


                <!-- Login Button -->
                <button
                    type="submit"
                    class="mt-7 w-full rounded-full bg-[#1D4ED8] px-5 py-3.5 text-sm font-medium text-[#F5F8FC] shadow-[0_5px_0_0_#12326b] transition-all hover:bg-[#2563EB] active:translate-y-1 active:shadow-none focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:ring-offset-2">

                    Masuk ke E-Learning

                </button>

                <!-- Register Link -->
                <div class="mt-2 pt-2 border-t border-[#DCE6F5] text-center">
                    <p class="text-sm text-[#0F2A4D]/55">
                        Belum memiliki akun?
                        <a
                            href="<?php echo e(route('register')); ?>"
                            class="font-semibold text-[#2563EB] hover:text-[#0F2A4D] transition-colors">
                            Daftar sekarang →
                        </a>
                    </p>
                </div>

            </form>

        </div>


        <!-- Footer -->
        <div class="border-t border-[#DCE6F5] bg-[#F5F8FC]/60 px-8 py-4 text-center">

            <p class="font-mono text-[10px] uppercase tracking-wider text-[#0F2A4D]/40">

                © <?php echo e(date('Y')); ?> Universitas Wiralodra

            </p>

        </div>

    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\elearning_ar\resources\views/auth/login.blade.php ENDPATH**/ ?>