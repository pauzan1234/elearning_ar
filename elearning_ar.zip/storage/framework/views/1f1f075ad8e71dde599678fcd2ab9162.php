<?php $__env->startSection('ketjudul'); ?>
Selamat Datang di
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Matakuliah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">

    <div>
        <h2 class="font-display text-lg font-semibold">
            Daftar Matakuliah
        </h2>

        <p class="text-sm text-ink/50 mt-0.5">
            Kelola data matakuliah berdasarkan program studi.
        </p>
    </div>

    <button type="button" onclick="document.getElementById('modalTambah').classList.remove('hidden')"
        class="inline-flex items-center justify-center gap-2
                   text-sm font-medium px-4 py-2 rounded-lg
                   bg-teal text-white hover:bg-teal/90
                   transition-colors">
        <span class="text-lg leading-none">+</span>
        Tambah Matakuliah
    </button>

</div>



<div class="border border-line rounded-xl p-4 mb-5 bg-white">

    <form action="" method="GET" class="flex flex-col sm:flex-row gap-3">

        
        <div class="flex-1">

            <label class="block text-xs font-medium text-ink/50 mb-1">
                Cari Matakuliah
            </label>

            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                placeholder="Kode atau nama matakuliah..."
                class="w-full border border-line rounded-lg px-3 py-2 text-sm
                           focus:outline-none focus:ring-2 focus:ring-teal/40">

        </div>


        
        <div class="sm:w-64">

            <label class="block text-xs font-medium text-ink/50 mb-1">
                Program Studi
            </label>

            <select name="prodi_id"
                class="w-full border border-line rounded-lg px-3 py-2 text-sm
                           bg-white focus:outline-none focus:ring-2 focus:ring-teal/40">

                <option value="">
                    Semua Program Studi
                </option>

                <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($prodi->id); ?>" <?php echo e(request('prodi_id') == $prodi->id ? 'selected' : ''); ?>>
                    <?php echo e($prodi->nama_prodi); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </div>


        
        <div class="flex items-end gap-2">

            <button type="submit"
                class="px-4 py-2 rounded-lg
                           bg-teal text-white text-sm font-medium
                           hover:bg-teal/90 transition-colors">
                Cari
            </button>

            <a href="<?php echo e(route('matakuliah.index')); ?>"
                class="px-4 py-2 rounded-lg
                           border border-line text-ink/70
                           text-sm font-medium
                           hover:bg-paper/60 transition-colors">
                Reset
            </a>

        </div>

    </form>

</div>



<div class="border border-line rounded-xl overflow-hidden bg-white">

    <div class="overflow-x-auto">

        <table class="w-full text-sm">

            <thead>
                <tr class="border-b border-line text-left bg-paper/40">

                    <th
                        class="py-3 px-4 font-medium text-ink/50
                                   font-mono text-xs uppercase tracking-wide">
                        No
                    </th>

                    <th
                        class="py-3 px-4 font-medium text-ink/50
                                   font-mono text-xs uppercase tracking-wide">
                        Kode MK
                    </th>

                    <th
                        class="py-3 px-4 font-medium text-ink/50
                                   font-mono text-xs uppercase tracking-wide">
                        Nama Matakuliah
                    </th>

                    <th
                        class="py-3 px-4 font-medium text-ink/50
                                   font-mono text-xs uppercase tracking-wide">
                        Program Studi
                    </th>

                    <th
                        class="py-3 px-4 font-medium text-ink/50
                                   font-mono text-xs uppercase tracking-wide">
                        SKS
                    </th>

                    <th
                        class="py-3 px-4 font-medium text-ink/50
                                   font-mono text-xs uppercase tracking-wide">
                        Aksi
                    </th>

                </tr>
            </thead>


            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $matakuliahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr
                    class="border-b border-line last:border-0
                                   hover:bg-paper/60 transition-colors">

                    
                    <td class="py-3 px-4 font-mono text-xs text-ink/60">
                        <?php echo e($matakuliahs->firstItem() + $index); ?>

                    </td>


                    
                    <td class="py-3 px-4 font-medium">
                        <?php echo e($mk->kode_mk); ?>

                    </td>


                    
                    <td class="py-3 px-4 text-ink/70">
                        <?php echo e($mk->nama_mk); ?>

                    </td>


                    
                    <td class="py-3 px-4 text-ink/70">
                        <?php echo e($mk->prodi->nama_prodi ?? '-'); ?>

                    </td>


                    
                    <td class="py-3 px-4">
                        <span
                            class="inline-flex items-center px-2.5 py-1
                                             rounded-md bg-teal/10 text-teal
                                             text-xs font-medium">
                            <?php echo e($mk->sks); ?> SKS
                        </span>
                    </td>


                    
                    <td class="py-3 px-4">

                        <div class="flex items-center gap-2">

                            
                            <button type="button"
                                onclick="bukaModalEdit('<?php echo e($mk->kode_mk); ?>', '<?php echo e($mk->nama_mk); ?>', '<?php echo e($mk->prodi_id); ?>', '<?php echo e($mk->sks); ?>')"
                                class="inline-flex items-center gap-1
           px-3 py-1.5 rounded-md
           text-xs font-medium
           bg-blue-500 text-white
           hover:bg-blue-600
           transition-colors">

                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M12 20h9" />
                                    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z" />
                                </svg>

                                Edit

                            </button>


                            
                            <form action="<?php echo e(route('matakuliah.destroy', $mk->kode_mk)); ?>" method="POST"
                                onsubmit="return confirm('Yakin ingin menghapus matakuliah ini?')">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit"
                                    class="inline-flex items-center gap-1
                                                   px-3 py-1.5 rounded-md
                                                   text-xs font-medium
                                                   bg-red-500 text-white
                                                   hover:bg-red-600
                                                   transition-colors">

                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M3 6h18" />
                                        <path d="M8 6V4h8v2" />
                                        <path d="M19 6v14H5V6" />
                                        <path d="M10 11v6" />
                                        <path d="M14 11v6" />
                                    </svg>

                                    Hapus

                                </button>

                            </form>

                        </div>

                    </td>

                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="6" class="py-10 text-center text-ink/40 text-sm">
                        Belum ada data matakuliah.

                    </td>

                </tr>
                <?php endif; ?>

            </tbody>

        </table>

    </div>


    
    <?php if($matakuliahs->hasPages()): ?>
    <div class="px-4 py-3 border-t border-line">
        <?php echo e($matakuliahs->links()); ?>

    </div>
    <?php endif; ?>

</div>



<div id="modalTambah" class="hidden fixed inset-0 z-50
               flex items-center justify-center p-4">

    
    <div class="absolute inset-0 bg-black/40" onclick="document.getElementById('modalTambah').classList.add('hidden')">
    </div>


    
    <div class="relative bg-white w-full max-w-md
                   rounded-xl shadow-lg p-6">

        <div class="flex items-center justify-between mb-5">

            <h3 class="font-display text-lg font-semibold">
                Tambah Matakuliah
            </h3>

            <button type="button" onclick="document.getElementById('modalTambah').classList.add('hidden')"
                class="text-ink/40 hover:text-ink/70 text-xl leading-none">
                &times;
            </button>

        </div>


        <form action="<?php echo e(route('admin.tambah.matkul')); ?>" method="POST">

            <?php echo csrf_field(); ?>


            
            <div class="mb-4">

                <label class="block text-sm font-medium text-ink/70 mb-1">
                    Kode Matakuliah
                </label>

                <input type="text" name="kode_mk" value="<?php echo e(old('kode_mk')); ?>" required maxlength="20"
                    placeholder="Contoh: TK101"
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm
                               focus:outline-none focus:ring-2 focus:ring-teal/40">

                <?php $__errorArgs = ['kode_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-red-500 mt-1">
                    <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            
            <div class="mb-4">

                <label class="block text-sm font-medium text-ink/70 mb-1">
                    Nama Matakuliah
                </label>

                <input type="text" name="nama_mk" value="<?php echo e(old('nama_mk')); ?>" required
                    placeholder="Masukkan nama matakuliah"
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm
                               focus:outline-none focus:ring-2 focus:ring-teal/40">

                <?php $__errorArgs = ['nama_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-red-500 mt-1">
                    <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            
            <div class="mb-4">

                <label class="block text-sm font-medium text-ink/70 mb-1">
                    Program Studi
                </label>

                <select name="prodi_id" required
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm
                               bg-white
                               focus:outline-none focus:ring-2 focus:ring-teal/40">

                    <option value="" disabled <?php echo e(old('prodi_id') ? '' : 'selected'); ?>>
                        Pilih Program Studi
                    </option>

                    <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prodi->id); ?>" <?php echo e(old('prodi_id') == $prodi->id ? 'selected' : ''); ?>>
                        <?php echo e($prodi->nama_prodi); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

                <?php $__errorArgs = ['prodi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-red-500 mt-1">
                    <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            
            <div class="mb-5">

                <label class="block text-sm font-medium text-ink/70 mb-1">
                    SKS
                </label>

                <input type="number" name="sks" value="<?php echo e(old('sks')); ?>" required min="1"
                    max="6" placeholder="Contoh: 3"
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm
                               focus:outline-none focus:ring-2 focus:ring-teal/40">

                <?php $__errorArgs = ['sks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-red-500 mt-1">
                    <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>


            
            <div class="flex justify-end gap-2">

                <button type="button" onclick="document.getElementById('modalTambah').classList.add('hidden')"
                    class="px-4 py-2 text-sm font-medium rounded-lg
                               border border-line text-ink/70
                               hover:bg-paper/60">
                    Batal
                </button>

                <button type="submit"
                    class="px-4 py-2 text-sm font-medium rounded-lg
                               bg-teal text-white hover:bg-teal/90">
                    Simpan
                </button>

            </div>

        </form>

    </div>

</div>

<div id="modalEdit" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4">

    <div class="absolute inset-0 bg-black/40" onclick="document.getElementById('modalEdit').classList.add('hidden')"></div>

    <div class="relative bg-white w-full max-w-md rounded-xl shadow-lg p-6">

        <div class="flex items-center justify-between mb-5">
            <h3 class="font-display text-lg font-semibold">Edit Matakuliah</h3>
            <button type="button" onclick="document.getElementById('modalEdit').classList.add('hidden')"
                class="text-ink/40 hover:text-ink/70 text-xl leading-none">
                &times;
            </button>
        </div>

        <form id="formEdit" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block text-sm font-medium text-ink/70 mb-1">Kode Matakuliah</label>
                <input type="text" id="edit_kode_mk" disabled
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm bg-paper/40 text-ink/50">
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-ink/70 mb-1">Nama Matakuliah</label>
                <input type="text" name="nama_mk" id="edit_nama_mk" required
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm
                           focus:outline-none focus:ring-2 focus:ring-teal/40">
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-ink/70 mb-1">Program Studi</label>
                <select name="prodi_id" id="edit_prodi_id" required
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm bg-white
                           focus:outline-none focus:ring-2 focus:ring-teal/40">
                    <option value="" disabled>Pilih Program Studi</option>
                    <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prodi->id); ?>"><?php echo e($prodi->nama_prodi); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-5">
                <label class="block text-sm font-medium text-ink/70 mb-1">SKS</label>
                <input type="number" name="sks" id="edit_sks" required min="1" max="6"
                    class="w-full border border-line rounded-lg px-3 py-2 text-sm
                           focus:outline-none focus:ring-2 focus:ring-teal/40">
            </div>

            <div class="flex justify-end gap-2">
                <button type="button" onclick="document.getElementById('modalEdit').classList.add('hidden')"
                    class="px-4 py-2 text-sm font-medium rounded-lg border border-line text-ink/70 hover:bg-paper/60">
                    Batal
                </button>
                <button type="submit"
                    class="px-4 py-2 text-sm font-medium rounded-lg bg-teal text-white hover:bg-teal/90">
                    Simpan Perubahan
                </button>
            </div>

        </form>

    </div>

</div>

<script>
    function bukaModalEdit(kodeMk, namaMk, prodiId, sks) {
        document.getElementById('edit_kode_mk').value = kodeMk;
        document.getElementById('edit_nama_mk').value = namaMk;
        document.getElementById('edit_prodi_id').value = prodiId;
        document.getElementById('edit_sks').value = sks;

        document.getElementById('formEdit').action = "<?php echo e(url('/admin/matakuliah')); ?>/" + kodeMk;

        document.getElementById('modalEdit').classList.remove('hidden');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app-admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\elearning_ar\resources\views/admin/matakuliah-index.blade.php ENDPATH**/ ?>