<?php $__env->startSection('ketjudul'); ?>
Mata Kuliah oleh
<?php $__currentLoopData = $pengajaran->pengajaranDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($pj->lecturer->user->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
<?php echo e($pengajaran->matakuliah->nama_mk); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<?php if(session('success')): ?>
<div class="mb-6 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="grid grid-cols-1 gap-8 lg:grid-cols-3">


    
    <div class="lg:col-span-2">


        
        <div class="mb-6 overflow-x-auto">

            <div class="flex min-w-max gap-1 rounded-xl border border-line bg-white p-1">

                
                <a href="#materi" class="rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white">
                    Materi
                </a>

                
                <a href="#tugas"
                    class="rounded-lg px-4 py-2.5 text-sm font-medium text-ink/60
                                   transition hover:bg-paper hover:text-ink">
                    Tugas
                </a>

                
                <a href="#quiz"
                    class="rounded-lg px-4 py-2.5 text-sm font-medium text-ink/60
                                   transition hover:bg-paper hover:text-ink">
                    Quiz
                </a>

                
                <a href="#mahasiswa"
                    class="relative rounded-lg px-4 py-2.5 text-sm font-medium text-ink/60
                                   transition hover:bg-paper hover:text-ink">
                    Mahasiswa
                    <?php if(isset($pengajuanPending) && $pengajuanPending->count()): ?>
                    <span
                        class="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center
                               rounded-full bg-amber-500 px-1 text-[10px] font-bold text-white">
                        <?php echo e($pengajuanPending->count()); ?>

                    </span>
                    <?php endif; ?>
                </a>
                
                <a href="#absensi"
                    class="rounded-lg px-4 py-2.5 text-sm font-medium text-ink/60
                                   transition hover:bg-paper hover:text-ink">
                    Absensi
                </a>
            </div>

        </div>


        
        <div id="materi" class="rounded-2xl border border-line bg-white shadow-sm">

            
            <div
                class="flex flex-col justify-between gap-4 border-b border-line p-6
                               sm:flex-row sm:items-center">

                <div>

                    <h2 class="font-display text-lg font-semibold text-ink">
                        Materi Pembelajaran
                    </h2>

                    <p class="mt-1 text-sm text-ink/50">
                        Kelola materi yang akan diberikan kepada mahasiswa.
                    </p>

                </div>


                
                <div class="flex items-center gap-2">

                    
                    <a href="<?php echo e(route('materi.create', $pengajaranDosen->id)); ?>"
                        class="inline-flex items-center justify-center gap-2 rounded-lg
                       bg-ink px-4 py-2.5 text-sm font-semibold text-white
                       transition hover:bg-primaryDark">

                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 4v16m8-8H4" />

                        </svg>

                        Tambah Materi

                    </a>

                    
                    <a href="<?php echo e(route('materi-ar.create', $pengajaranDosen->id)); ?>"
                        class="inline-flex items-center justify-center gap-2 rounded-lg
                       border border-teal/30 bg-teal/10 px-4 py-2.5 text-sm font-semibold text-teal
                       transition hover:bg-teal/20">

                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 7l8-4 8 4M4 7l8 4m-8-4v10l8 4m0-10l8-4m-8 4v10m8-10v10l-8 4" />
                        </svg>

                        Tambah Materi AR

                    </a>

                </div>
            </div>


            
            <div class="divide-y divide-line">

                <?php $__empty_1 = true; $__currentLoopData = $materiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <?php
                $labelTipe = $materi->files
                ->map(function ($file) {
                return match ($file->tipe) {
                'pdf' => 'PDF',
                'audio' => 'Audio',
                'video_youtube' => 'Video',
                default => ucfirst($file->tipe),
                };
                })
                ->unique()
                ->when($materi->materiAr->isNotEmpty(), fn ($c) => $c->push('AR'))
                ->implode(', ');
                ?>

                <div x-data="{ open: false }">

                    
                    <div class="flex items-center gap-4 p-5">

                        <button type="button" @click="open = !open"
                            class="flex flex-1 items-center gap-4 text-left min-w-0">

                            
                            <div
                                class="flex h-11 w-11 shrink-0 items-center justify-center
                                               rounded-xl bg-paper text-ink">

                                <svg class="h-5 w-5" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5
                                                               S4.168 5.477 3 6.253v13
                                                               C4.168 18.477 5.754 18 7.5 18
                                                               s3.332.477 4.5 1.253
                                                               m0-13C13.168 5.477 14.754 5
                                                               16.5 5c1.746 0 3.332.477 4.5 1.253v13
                                                               C19.832 18.477 18.246 18 16.5 18
                                                               c-1.746 0-3.332.477-4.5 1.253" />

                                </svg>

                            </div>


                            
                            <div class="min-w-0 flex-1">

                                <h3 class="truncate text-sm font-semibold text-ink">
                                    <?php echo e($materi->judul); ?>

                                </h3>

                                <p class="mt-1 text-xs text-ink/50">
                                    Materi pembelajaran
                                    <?php if($labelTipe): ?>
                                    • <?php echo e($labelTipe); ?>

                                    <?php endif; ?>
                                </p>

                            </div>

                            
                            <svg class="h-4 w-4 shrink-0 text-ink/30 transition-transform"
                                :class="open ? 'rotate-180' : ''" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M19 9l-7 7-7-7" />
                            </svg>

                        </button>

                        
                        <?php $__currentLoopData = $materi->materiAr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('materi-ar.show', $ar->id)); ?>"
                            target="_blank" rel="noopener"
                            title="<?php echo e($ar->judul); ?>"
                            class="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-line
               px-3 py-1.5 text-xs font-semibold text-ink transition hover:bg-paper">
                            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
                            </svg>
                            Lihat AR
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="relative shrink-0" x-data="{ menuOpen: false }">

                            <button type="button" @click="menuOpen = !menuOpen"
                                @click.outside="menuOpen = false"
                                class="rounded-lg p-2 text-ink/35
                                               transition hover:bg-paper hover:text-ink">

                                <svg class="h-5 w-5" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 5v.01M12 12v.01M12 19v.01" />

                                </svg>

                            </button>

                            <div x-show="menuOpen" x-cloak
                                class="absolute right-0 z-10 mt-1 w-40 rounded-lg border
                                               border-line bg-white py-1 shadow-lg">

                                <a href="<?php echo e(route('materi.edit', $materi->id)); ?>"
                                    class="block w-full px-4 py-2 text-left text-sm
                                                   text-ink/70 hover:bg-paper">
                                    Edit
                                </a>

                                <form method="POST"
                                    action="<?php echo e(route('materi.destroy', $materi->id)); ?>"
                                    onsubmit="return confirm('Yakin ingin menghapus materi ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit"
                                        class="block w-full px-4 py-2 text-left text-sm
                                                       text-red-600 hover:bg-red-50">
                                        Hapus
                                    </button>
                                </form>

                            </div>

                        </div>

                    </div>


                    
                    <div x-show="open" x-cloak class="space-y-5 px-5 pb-5">

                        <?php if($materi->deskripsi): ?>
                        <div class="prose prose-sm max-w-none text-sm text-ink/60">
                            <?php echo $materi->deskripsi; ?>

                        </div>
                        <?php endif; ?>

                        <?php $__currentLoopData = $materi->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($file->tipe === 'pdf'): ?>
                        
                        <div>
                            <div class="mb-2 flex items-center justify-between">
                                <span class="text-xs font-medium text-ink/50">
                                    <?php echo e($file->nama_asli ?? 'Dokumen PDF'); ?>

                                </span>
                                <a href="<?php echo e($file->url); ?>" target="_blank"
                                    class="text-xs font-medium text-blue-600 hover:underline">
                                    Buka di tab baru
                                </a>
                            </div>

                            <iframe src="<?php echo e($file->url); ?>"
                                class="h-[480px] w-full rounded-xl border border-line"
                                loading="lazy"></iframe>
                        </div>
                        <?php $__currentLoopData = $materi->materiAr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between gap-3 rounded-xl border border-line bg-paper p-4">
                            <div class="min-w-0">
                                <p class="truncate text-sm font-semibold text-ink"><?php echo e($ar->judul); ?></p>
                                <p class="mt-0.5 text-xs text-ink/50">
                                    AR <?php echo e($ar->tipe_ar === 'marker' ? 'dengan marker' : 'tanpa marker'); ?>

                                </p>
                            </div>
                            <a href="<?php echo e(route('materi-ar.show', $ar->id)); ?>" target="_blank" rel="noopener"
                                class="shrink-0 rounded-lg bg-ink px-3 py-1.5 text-xs font-semibold text-white
                   transition hover:bg-primaryDark">
                                Buka AR
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif($file->tipe === 'audio'): ?>
                        
                        <div>
                            <p class="mb-2 text-xs font-medium text-ink/50">
                                <?php echo e($file->nama_asli ?? 'Rekaman Audio'); ?>

                            </p>

                            <audio controls class="w-full">
                                <source src="<?php echo e($file->url); ?>">
                                Browser kamu tidak mendukung pemutar audio.
                            </audio>
                        </div>
                        <?php elseif($file->tipe === 'video_youtube' && $file->youtube_embed_url): ?>
                        
                        <div>
                            <p class="mb-2 text-xs font-medium text-ink/50">
                                Video Pembelajaran
                            </p>

                            <div
                                class="aspect-video w-full overflow-hidden rounded-xl border border-line">
                                <iframe src="<?php echo e($file->youtube_embed_url); ?>" class="h-full w-full"
                                    loading="lazy"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen></iframe>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                
                <div class="p-6">

                    <div
                        class="rounded-xl border border-dashed border-line
                                       bg-paper p-8 text-center">

                        <p class="text-sm text-ink/50">
                            Belum ada materi. Klik "Tambah Materi" untuk mulai menambahkan.
                        </p>

                    </div>

                </div>
                <?php endif; ?>

            </div>

        </div>


        
        <div id="tugas" class="mt-8 overflow-hidden rounded-2xl border border-line bg-white shadow-sm">

            
            <div
                class="flex flex-col justify-between gap-4 border-b border-line p-6
                               sm:flex-row sm:items-center">

                <div>

                    <h2 class="font-display text-lg font-semibold text-ink">
                        Tugas
                    </h2>

                    <p class="mt-1 text-sm text-ink/50">
                        Kelola tugas dan pengumpulan mahasiswa.
                    </p>

                </div>


                <a href="<?php echo e(route('tugas.create', $pengajaranDosen->id)); ?>"
                    class="rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white
           transition hover:bg-primaryDark">
                    + Tambah Tugas
                </a>

            </div>





            
            <div class="divide-y divide-line">

                <?php $__empty_1 = true; $__currentLoopData = $tugasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between gap-4 p-5">

                    <a href="<?php echo e(route('tugas.show', $tugas->id)); ?>" class="min-w-0 flex-1">
                        <h3 class="truncate text-sm font-semibold text-ink hover:underline">
                            <?php echo e($tugas->judul); ?>

                        </h3>
                        <p class="mt-1 text-xs text-ink/50">
                            <?php if($tugas->deadline): ?>
                            Deadline: <?php echo e($tugas->deadline->format('d M Y, H:i')); ?>

                            <?php else: ?>
                            Tanpa deadline
                            <?php endif; ?>
                            • <?php echo e($tugas->jawaban_count ?? $tugas->jawaban->count()); ?> pengumpulan
                        </p>
                    </a>
                    <a href="<?php echo e(route('tugas.jawaban.index', $tugas)); ?>"
                        class="rounded-lg border border-line px-4 py-2.5 text-sm font-semibold text-ink transition hover:bg-paper">
                        Lihat & Koreksi Jawaban
                    </a>
                    <div class="flex shrink-0 items-center gap-2">
                        <a href="<?php echo e(route('tugas.show', $tugas->id)); ?>"
                            class="rounded-lg border border-line px-3 py-1.5 text-xs font-semibold text-ink hover:bg-paper">
                            Lihat
                        </a>
                        <a href="<?php echo e(route('tugas.edit', $tugas->id)); ?>"
                            class="rounded-lg border border-line px-3 py-1.5 text-xs font-semibold text-ink hover:bg-paper">
                            Edit
                        </a>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                
                <div class="p-6">

                    <div
                        class="rounded-xl border border-dashed border-line
                   bg-paper p-8 text-center">

                        <p class="text-sm text-ink/50">
                            Belum ada tugas.
                        </p>

                    </div>

                </div>
                <?php endif; ?>



            </div>

        </div>


        
        <div id="quiz" class="mt-8 overflow-hidden rounded-2xl border border-line bg-white shadow-sm">

            
            <div
                class="flex flex-col justify-between gap-4 border-b border-line p-6
                               sm:flex-row sm:items-center">

                <div>

                    <h2 class="font-display text-lg font-semibold text-ink">
                        Quiz
                    </h2>

                    <p class="mt-1 text-sm text-ink/50">
                        Kelola quiz pilihan ganda untuk mata kuliah ini.
                    </p>

                </div>

                
                <a href="<?php echo e(route('lecturer.quiz.index', $pengajaranDosen->id)); ?>"
                    class="inline-flex items-center justify-center gap-2 rounded-lg
                                   bg-ink px-4 py-2.5 text-sm font-semibold text-white
                                   transition hover:bg-primaryDark">

                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 4v16m8-8H4" />

                    </svg>

                    Buat Quiz

                </a>

            </div>


            
            <div class="divide-y divide-line">

                <?php $__empty_1 = true; $__currentLoopData = $quizList ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('lecturer.quiz.show', $quiz)); ?>"
                    class="flex items-center justify-between gap-4 p-5 transition hover:bg-paper">

                    <div class="min-w-0 flex-1">
                        <h3 class="truncate text-sm font-semibold text-ink">
                            <?php echo e($quiz->judul); ?>

                        </h3>
                        <p class="mt-1 text-xs text-ink/50">
                            <?php echo e($quiz->questions_count ?? $quiz->questions->count()); ?> soal
                            <?php if($quiz->durasi_menit): ?>
                            • <?php echo e($quiz->durasi_menit); ?> menit
                            <?php endif; ?>
                        </p>
                    </div>

                    <?php if($quiz->is_published): ?>
                    <span
                        class="shrink-0 rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                        Published
                    </span>
                    <?php else: ?>
                    <span
                        class="shrink-0 rounded-full bg-yellow-50 px-3 py-1 text-xs font-semibold text-yellow-700">
                        Draft
                    </span>
                    <?php endif; ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                
                <div class="p-6">

                    <div
                        class="rounded-xl border border-dashed border-line
                                       bg-paper p-8 text-center">

                        <p class="text-sm text-ink/50">
                            Belum ada quiz. Klik "Buat Quiz" untuk mulai menambahkan.
                        </p>

                    </div>

                </div>
                <?php endif; ?>

            </div>

        </div>

        
        <div id="mahasiswa" class="mt-8 overflow-hidden rounded-2xl border border-line bg-white shadow-sm">

            
            <div
                class="flex flex-col justify-between gap-4 border-b border-line p-6
                sm:flex-row sm:items-center">
                <div>
                    <h2 class="font-display text-lg font-semibold text-ink">
                        Mahasiswa
                    </h2>
                    <p class="mt-1 text-sm text-ink/50">
                        Daftar mahasiswa yang mengambil kelas ini.
                    </p>
                </div>

                <span class="text-sm font-medium text-ink/60">
                    <?php echo e($pengajaran->mahasiswa->count()); ?> mahasiswa
                </span>
            </div>

            
            <?php if(isset($pengajuanPending) && $pengajuanPending->count()): ?>
            <div class="border-b border-line bg-amber-50/60 p-6">
                <h3 class="text-sm font-semibold text-amber-800">
                    <?php echo e($pengajuanPending->count()); ?> mahasiswa mengajukan masuk kelas ini
                </h3>

                <div class="mt-3 divide-y divide-amber-100">
                    <?php $__currentLoopData = $pengajuanPending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between gap-3 py-3">
                        <div class="flex min-w-0 items-center gap-3">
                            <div
                                class="flex h-9 w-9 shrink-0 items-center justify-center
                                       rounded-full bg-white text-xs font-semibold text-amber-700">
                                <?php echo e(strtoupper(substr($pengajuan->mahasiswa->user->name ?? 'M', 0, 1))); ?>

                            </div>
                            <div class="min-w-0">
                                <p class="truncate text-sm font-medium text-ink">
                                    <?php echo e($pengajuan->mahasiswa->user->name ?? '-'); ?>

                                </p>
                                <p class="truncate text-xs text-ink/50">
                                    NIM <?php echo e($pengajuan->mahasiswa->nim ?? '-'); ?>

                                </p>
                            </div>
                        </div>

                        <div class="flex shrink-0 gap-2">
                            <form method="POST"
                                action="<?php echo e(route('lecturer.pengajuan.approve', $pengajuan->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="rounded-lg bg-green-600 px-3 py-1.5 text-xs font-semibold text-white
                                           transition hover:bg-green-700">
                                    Setujui
                                </button>
                            </form>

                            <form method="POST"
                                action="<?php echo e(route('lecturer.pengajuan.reject', $pengajuan->id)); ?>"
                                onsubmit="return confirm('Tolak pengajuan mahasiswa ini?')">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="rounded-lg border border-red-200 bg-white px-3 py-1.5 text-xs font-semibold
                                           text-red-600 transition hover:bg-red-50">
                                    Tolak
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            
            <div class="divide-y divide-line">

                <?php $__empty_1 = true; $__currentLoopData = $pengajaran->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center gap-4 p-5">

                    
                    <div
                        class="flex h-11 w-11 shrink-0 items-center justify-center
                        rounded-full bg-paper text-sm font-semibold text-ink">
                        <?php echo e(strtoupper(substr($mhs->user->name ?? 'M', 0, 1))); ?>

                    </div>

                    
                    <div class="min-w-0 flex-1">
                        <h3 class="truncate text-sm font-semibold text-ink">
                            <?php echo e($mhs->user->name ?? '-'); ?>

                        </h3>
                        <p class="mt-1 text-xs text-ink/50">
                            NIM: <?php echo e($mhs->nim ?? '-'); ?>

                        </p>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                
                <div class="p-6">
                    <div
                        class="rounded-xl border border-dashed border-line
                        bg-paper p-8 text-center">
                        <p class="text-sm text-ink/50">
                            Belum ada mahasiswa yang mengambil kelas ini.
                        </p>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
        
        
        <div id="absensi" class="mt-8 overflow-hidden rounded-2xl border border-line bg-white shadow-sm">

            
            
            <div class="flex flex-col justify-between gap-4 border-b border-line p-6 sm:flex-row sm:items-center">
                <div>
                    <h2 class="font-display text-lg font-semibold text-ink">Absensi</h2>
                    <p class="mt-1 text-sm text-ink/50">Kelola kehadiran mahasiswa per pertemuan.</p>
                </div>

                <div class="flex items-center gap-2">
                    
                    <a href="<?php echo e(route('lecturer.absensi.rekapSemua', $pengajaranDosen->id)); ?>"
                        class="rounded-lg border border-line px-4 py-2.5 text-sm font-semibold text-ink
                   transition hover:bg-paper">
                        Rekap Semua
                    </a>

                    
                    <button type="button" @click="$dispatch('open-modal-absensi')"
                        class="rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white
                   transition hover:bg-primaryDark">
                        + Buka Absensi
                    </button>
                </div>
            </div>

            
            <div class="divide-y divide-line">

                <?php $__empty_1 = true; $__currentLoopData = $sesiAbsensiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('lecturer.absensi.show', $s->id)); ?>"
                    class="flex items-center justify-between gap-4 p-5 transition hover:bg-paper">

                    <div>
                        <h3 class="text-sm font-semibold text-ink">
                            Pertemuan <?php echo e($s->pertemuan_ke); ?>

                            <?php if($s->judul): ?>
                            — <?php echo e($s->judul); ?>

                            <?php endif; ?>
                        </h3>
                        <p class="mt-1 text-xs text-ink/50">
                            <?php echo e($s->dibuka_pada->format('d M Y, H:i')); ?>

                            • <?php echo e($s->absensi()->count()); ?> mahasiswa hadir
                        </p>
                    </div>

                    <?php if($s->isExpired()): ?>
                    <span class="rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-600">
                        Ditutup
                    </span>
                    <?php else: ?>
                    <span
                        class="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                        Aktif
                    </span>
                    <?php endif; ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="p-6">
                    <div class="rounded-xl border border-dashed border-line bg-paper p-8 text-center">
                        <p class="text-sm text-ink/50">
                            Belum ada sesi absensi untuk mata kuliah ini.
                        </p>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>


    
    <div class="space-y-6">


        
        <div class="rounded-2xl border border-line bg-white p-6 shadow-sm">

            <h2 class="font-display text-base font-semibold text-ink">
                Aksi Cepat
            </h2>


            <div class="mt-4 space-y-3">


                
                <a href="<?php echo e(route('materi.create', $pengajaranDosen->id)); ?>"
                    class="flex w-full items-center gap-3 rounded-xl border border-line
                                   p-3 text-left transition hover:bg-paper">

                    <div
                        class="flex h-10 w-10 items-center justify-center rounded-lg
                                       bg-paper text-ink">

                        +

                    </div>

                    <div>

                        <p class="text-sm font-semibold text-ink">
                            Tambah Materi
                        </p>

                        <p class="text-xs text-ink/50">
                            Upload materi pembelajaran
                        </p>

                    </div>

                </a>

                
                <a href="<?php echo e(route('materi-ar.create', $pengajaranDosen->id)); ?>"
                    class="flex w-full items-center gap-3 rounded-xl border border-teal/20 bg-teal/5
                   p-3 text-left transition hover:bg-teal/10">

                    <div
                        class="flex h-10 w-10 items-center justify-center rounded-lg
                       bg-teal/15 text-teal">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 7l8-4 8 4M4 7l8 4m-8-4v10l8 4m0-10l8-4m-8 4v10m8-10v10l-8 4" />
                        </svg>
                    </div>

                    <div>

                        <p class="text-sm font-semibold text-ink">
                            Tambah Materi AR
                        </p>

                        <p class="text-xs text-ink/50">
                            Upload model 3D bangun ruang
                        </p>

                    </div>

                </a>

                
                <a href="<?php echo e(route('tugas.create', $pengajaranDosen->id)); ?>"
                    class="flex w-full items-center gap-3 rounded-xl border border-line
                                   p-3 text-left transition hover:bg-paper">

                    <div
                        class="flex h-10 w-10 items-center justify-center rounded-lg
                                       bg-paper text-ink">

                        +

                    </div>

                    <div>

                        <p class="text-sm font-semibold text-ink">
                            Buat Tugas
                        </p>

                        <p class="text-xs text-ink/50">
                            Tambahkan tugas
                        </p>

                    </div>

                </a>


                
                <a href="<?php echo e(route('lecturer.quiz.index', $pengajaranDosen->id)); ?>"
                    class="flex w-full items-center gap-3 rounded-xl border border-line
                                   p-3 text-left transition hover:bg-paper">

                    <div
                        class="flex h-10 w-10 items-center justify-center rounded-lg
                                       bg-paper text-ink">

                        +

                    </div>

                    <div>

                        <p class="text-sm font-semibold text-ink">
                            Buat Quiz
                        </p>

                        <p class="text-xs text-ink/50">
                            Tambahkan quiz
                        </p>

                    </div>

                </a>


            </div>
            <div class="mt-4 space-y-3">
                
                <a href="<?php echo e(route('lecturer.rekap.nilai', $pengajaranDosen->id)); ?>"
                    class="flex w-full items-center gap-3 rounded-xl border border-line
           p-3 text-left transition hover:bg-paper">

                    <div class="flex h-10 w-10 items-center justify-center rounded-lg
               bg-paper text-ink">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1M7 10l5 5 5-5M12 15V3" />
                        </svg>
                    </div>

                    <div>
                        <p class="text-sm font-semibold text-ink">
                            Download Rekap Nilai
                        </p>
                        <p class="text-xs text-ink/50">
                            Excel: nilai Quiz &amp; Tugas
                        </p>
                    </div>

                </a>
            </div>
        </div>


        
        <div class="rounded-2xl border border-line bg-white p-6 shadow-sm">

            <h2 class="font-display text-base font-semibold text-ink">
                Ringkasan
            </h2>


            <div class="mt-5 space-y-4">


                <div class="flex items-center justify-between">

                    <span class="text-sm text-ink/50">
                        Materi
                    </span>

                    <span class="font-semibold text-ink">
                        <?php echo e($materiList->count()); ?>

                    </span>

                </div>


                <div class="flex items-center justify-between">
                    <span class="text-sm text-ink/50">Tugas</span>
                    <span class="font-semibold text-ink">
                        <?php echo e($tugasList->count()); ?>

                    </span>
                </div>


                <div class="flex items-center justify-between">

                    <span class="text-sm text-ink/50">
                        Quiz
                    </span>

                    <span class="font-semibold text-ink">
                        <?php echo e(isset($quizList) ? $quizList->count() : 0); ?>

                    </span>

                </div>


                <div class="flex items-center justify-between">
                    <span class="text-sm text-ink/50">Mahasiswa</span>
                    <span class="font-semibold text-ink">
                        <?php echo e($pengajaran->mahasiswa->count()); ?>

                    </span>
                </div>


            </div>

        </div>


    </div>

</div>

</div>

</div>

<div x-data="{ open: false }" x-show="open" x-cloak @open-modal-absensi.window="open = true"
    @keydown.escape.window="open = false" class="fixed inset-0 z-50 flex items-center justify-center p-4"
    style="display: none;">

    
    <div x-show="open" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" @click="open = false"
        class="absolute inset-0 bg-ink/40"></div>

    
    <div x-show="open" x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
        x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100 scale-100"
        x-transition:leave-end="opacity-0 scale-95"
        class="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">

        
        <div class="flex items-center justify-between">
            <h2 class="font-display text-lg font-semibold text-ink">
                Buka Sesi Absensi
            </h2>
            <button type="button" @click="open = false"
                class="rounded-lg p-1.5 text-ink/40 transition hover:bg-paper hover:text-ink">
                <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <p class="mt-1 text-sm text-ink/50">
            QR code akan digenerate otomatis setelah sesi dibuka.
        </p>

        
        <form method="POST" action="<?php echo e(route('lecturer.absensi.store', $pengajaran->id)); ?>" class="mt-5 space-y-4">
            <?php echo csrf_field(); ?>

            
            <div>
                <label class="block text-sm font-medium text-ink">
                    Pertemuan Ke
                </label>
                <input type="number" name="pertemuan_ke" min="1" required
                    value="<?php echo e(old('pertemuan_ke', $sesiAbsensiList->count() + 1)); ?>"
                    class="mt-1.5 w-full rounded-lg border border-line px-3.5 py-2.5 text-sm
                           text-ink outline-none transition focus:border-ink">
                <?php $__errorArgs = ['pertemuan_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="block text-sm font-medium text-ink">
                    Judul / Topik <span class="text-ink/40">(opsional)</span>
                </label>
                <input type="text" name="judul" value="<?php echo e(old('judul')); ?>"
                    placeholder="Misal: Normalisasi Database"
                    class="mt-1.5 w-full rounded-lg border border-line px-3.5 py-2.5 text-sm
                           text-ink outline-none transition focus:border-ink">
                <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="block text-sm font-medium text-ink">
                    Durasi QR Aktif (menit)
                </label>
                <input type="number" name="durasi_menit" min="1" max="180" required
                    value="<?php echo e(old('durasi_menit', 15)); ?>"
                    class="mt-1.5 w-full rounded-lg border border-line px-3.5 py-2.5 text-sm
                           text-ink outline-none transition focus:border-ink">
                <?php $__errorArgs = ['durasi_menit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mt-6 flex justify-end gap-3">
                <button type="button" @click="open = false"
                    class="rounded-lg border border-line px-4 py-2.5 text-sm font-semibold text-ink
                           transition hover:bg-paper">
                    Batal
                </button>
                <button type="submit"
                    class="rounded-lg bg-ink px-4 py-2.5 text-sm font-semibold text-white
                           transition hover:bg-primaryDark">
                    Buka Absensi
                </button>
            </div>

        </form>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lecturer.app-lecturer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\elearning_ar\resources\views/lecturer/show.blade.php ENDPATH**/ ?>