<?php $__env->startSection('ketjudul', 'Akademik'); ?>
<?php $__env->startSection('judul', 'Jadwal Mata Kuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <?php if(session('success')): ?>
        <div class="p-4 rounded-xl bg-green-50 border border-green-200 text-green-700 text-sm"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(Auth::user()->role === 'admin'): ?>
    <div class="grid xl:grid-cols-2 gap-5">
        <div class="border border-line rounded-xl p-5">
            <h2 class="font-semibold mb-4">Tambah Jadwal</h2>
            <form method="POST" action="<?php echo e(route('admin.jadwal.store')); ?>" class="grid sm:grid-cols-2 gap-4">
                <?php echo csrf_field(); ?>
                <div class="sm:col-span-2">
                    <label class="text-xs font-medium text-ink/60">Mata Kuliah / Kelas</label>
                    <select name="kelas_id" required class="mt-1 w-full rounded-lg border-line text-sm">
                        <option value="">Pilih kelas</option>
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->kode_mk); ?> - <?php echo e($kelas->matakuliah->nama_mk ?? '-'); ?> (Kelas <?php echo e($kelas->kode_kelas); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div><label class="text-xs font-medium text-ink/60">Hari</label><select name="hari" required class="mt-1 w-full rounded-lg border-line text-sm"><?php $__currentLoopData = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option><?php echo e($hari); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div><label class="text-xs font-medium text-ink/60">Ruangan</label><input name="ruangan" maxlength="100" class="mt-1 w-full rounded-lg border-line text-sm" placeholder="Contoh: R.201"></div>
                <div><label class="text-xs font-medium text-ink/60">Jam Mulai</label><input type="time" name="jam_mulai" required class="mt-1 w-full rounded-lg border-line text-sm"></div>
                <div><label class="text-xs font-medium text-ink/60">Jam Selesai</label><input type="time" name="jam_selesai" required class="mt-1 w-full rounded-lg border-line text-sm"></div>
                <div class="sm:col-span-2"><button class="px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold">Simpan Jadwal</button></div>
            </form>
        </div>

        <div class="border border-line rounded-xl p-5">
            <h2 class="font-semibold mb-2">Import Jadwal</h2>
            <p class="text-sm text-ink/55 mb-4">Format kolom: kode_mk, kode_kelas, hari, jam_mulai, jam_selesai, ruangan.</p>
            <a href="<?php echo e(route('admin.jadwal.template')); ?>" class="inline-flex mb-4 text-sm font-medium text-blue-600 hover:text-blue-800">Unduh template Excel</a>
            <form method="POST" action="<?php echo e(route('admin.jadwal.import')); ?>" enctype="multipart/form-data" class="space-y-3">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" accept=".xlsx,.xls,.csv" required class="block w-full text-sm border border-line rounded-lg p-2">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="px-4 py-2.5 rounded-lg bg-ink text-white text-sm font-semibold">Import Semua Jadwal</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="border border-line rounded-xl overflow-hidden">
        <div class="px-5 py-4 border-b border-line"><h2 class="font-semibold">Daftar Jadwal</h2></div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-slate-50 text-ink/55 text-left"><tr><th class="px-4 py-3">Hari</th><th class="px-4 py-3">Mata Kuliah</th><th class="px-4 py-3">Kelas</th><th class="px-4 py-3">Waktu</th><th class="px-4 py-3">Ruangan</th><?php if(Auth::user()->role === 'admin'): ?><th class="px-4 py-3">Aksi</th><?php endif; ?></tr></thead>
                <tbody class="divide-y divide-line">
                <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="align-top">
                        <?php if(Auth::user()->role === 'admin'): ?>
                        <form method="POST" action="<?php echo e(route('admin.jadwal.update', $jadwal)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <td class="px-4 py-3"><select name="hari" class="rounded-lg border-line text-sm"><?php $__currentLoopData = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if($jadwal->hari===$hari): echo 'selected'; endif; ?>><?php echo e($hari); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td>
                        <td class="px-4 py-3 min-w-[260px]"><select name="kelas_id" class="w-full rounded-lg border-line text-sm"><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($kelas->id); ?>" <?php if($jadwal->kelas_id===$kelas->id): echo 'selected'; endif; ?>><?php echo e($kelas->kode_mk); ?> - <?php echo e($kelas->matakuliah->nama_mk ?? '-'); ?> / <?php echo e($kelas->kode_kelas); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td>
                        <td class="px-4 py-3"><?php echo e($jadwal->kelas->kode_kelas); ?></td>
                        <td class="px-4 py-3 whitespace-nowrap"><input type="time" name="jam_mulai" value="<?php echo e(substr($jadwal->jam_mulai,0,5)); ?>" class="rounded-lg border-line text-sm"> <span class="mx-1">-</span> <input type="time" name="jam_selesai" value="<?php echo e(substr($jadwal->jam_selesai,0,5)); ?>" class="rounded-lg border-line text-sm"></td>
                        <td class="px-4 py-3"><input name="ruangan" value="<?php echo e($jadwal->ruangan); ?>" class="w-28 rounded-lg border-line text-sm"></td>
                        <td class="px-4 py-3 whitespace-nowrap"><button class="text-blue-600 hover:text-blue-800 font-medium">Simpan</button></form><form method="POST" action="<?php echo e(route('admin.jadwal.destroy', $jadwal)); ?>" class="inline ml-3" onsubmit="return confirm('Hapus jadwal ini?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="text-red-600 hover:text-red-800">Hapus</button></form></td>
                        <?php else: ?>
                        <td class="px-4 py-3 font-medium"><?php echo e($jadwal->hari); ?></td>
                        <td class="px-4 py-3"><p class="font-medium"><?php echo e($jadwal->kelas->matakuliah->nama_mk ?? $jadwal->kelas->kode_mk); ?></p><p class="text-xs text-ink/40 font-mono"><?php echo e($jadwal->kelas->kode_mk); ?></p></td>
                        <td class="px-4 py-3"><?php echo e($jadwal->kelas->kode_kelas); ?></td>
                        <td class="px-4 py-3 whitespace-nowrap"><?php echo e(substr($jadwal->jam_mulai,0,5)); ?> - <?php echo e(substr($jadwal->jam_selesai,0,5)); ?></td>
                        <td class="px-4 py-3"><?php echo e($jadwal->ruangan ?: '-'); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="px-4 py-8 text-center text-ink/45">Belum ada jadwal mata kuliah.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->role === 'admin' ? 'admin.app-admin' : (Auth::user()->role === 'lecturer' ? 'lecturer.app-lecturer' : 'student.app-student'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\elearning_ar\resources\views/jadwal/index.blade.php ENDPATH**/ ?>