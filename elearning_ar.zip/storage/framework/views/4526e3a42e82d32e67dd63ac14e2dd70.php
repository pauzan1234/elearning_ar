<?php $__env->startSection('ketjudul', 'Dashboard'); ?>
<?php $__env->startSection('judul', 'Ringkasan Belajar Saya'); ?>
<?php $__env->startSection('content'); ?>
<div class="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
    <a href="<?php echo e(route('student.matakuliah.index')); ?>" class="rounded-2xl border border-line bg-white p-6 shadow-sm transition hover:shadow-md">
        <p class="text-xs font-mono uppercase tracking-wide text-ink/45">Mata Kuliah</p>
        <p class="mt-4 font-display text-3xl font-semibold"><?php echo e($totalMatkul); ?></p>
        <p class="mt-1 text-sm text-ink/50">Mata kuliah yang diikuti</p>
    </a>
    <a href="<?php echo e(route('student.akademik.tugas.index')); ?>" class="rounded-2xl border border-line bg-white p-6 shadow-sm transition hover:shadow-md">
        <p class="text-xs font-mono uppercase tracking-wide text-ink/45">Tugas</p>
        <p class="mt-4 font-display text-3xl font-semibold"><?php echo e($pendingTugas); ?></p>
        <p class="mt-1 text-sm text-ink/50">Belum dikumpulkan</p>
    </a>
    <a href="<?php echo e(route('student.akademik.quiz.index')); ?>" class="rounded-2xl border border-line bg-white p-6 shadow-sm transition hover:shadow-md">
        <p class="text-xs font-mono uppercase tracking-wide text-ink/45">Quiz</p>
        <p class="mt-4 font-display text-3xl font-semibold"><?php echo e($pendingQuiz); ?></p>
        <p class="mt-1 text-sm text-ink/50">Belum dikerjakan</p>
    </a>
    <a href="<?php echo e(route('student.akademik.nilai.index')); ?>" class="rounded-2xl border border-line bg-white p-6 shadow-sm transition hover:shadow-md">
        <p class="text-xs font-mono uppercase tracking-wide text-ink/45">Rata-rata Nilai</p>
        <p class="mt-4 font-display text-3xl font-semibold"><?php echo e($nilaiRataRata !== null ? number_format((float)$nilaiRataRata, 2) : '-'); ?></p>
        <p class="mt-1 text-sm text-ink/50">Rata-rata tugas dan quiz yang sudah dinilai</p>
    </a>
</div>

<div class="mt-8 grid gap-6 xl:grid-cols-2">
    <section class="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-line p-5">
            <div><h2 class="font-display text-lg font-semibold">Tugas yang Perlu Dikerjakan</h2><p class="mt-1 text-xs text-ink/45">Tugas yang belum kamu submit.</p></div>
            <a href="<?php echo e(route('student.akademik.tugas.index')); ?>" class="text-sm font-semibold text-teal">Lihat semua</a>
        </div>
        <div class="divide-y divide-line">
            <?php $__empty_1 = true; $__currentLoopData = $tugasTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('student.tugas.show', $tugas)); ?>" class="block p-5 transition hover:bg-paper">
                    <div class="flex items-start justify-between gap-4">
                        <div><p class="font-semibold"><?php echo e($tugas->judul); ?></p><p class="mt-1 text-xs text-ink/45"><?php echo e($tugas->pengajaranDosen->kelas->matakuliah->nama_mk ?? '-'); ?> · Kelas <?php echo e($tugas->pengajaranDosen->kelas->kode_kelas ?? '-'); ?></p></div>
                        <span class="shrink-0 rounded-full bg-yellow-50 px-3 py-1 text-xs font-semibold text-yellow-700"><?php echo e($tugas->deadline?->format('d M H:i') ?? 'Tanpa deadline'); ?></span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-8 text-center text-sm text-ink/50">Tidak ada tugas yang belum dikumpulkan.</div>
            <?php endif; ?>
        </div>
    </section>

    <section class="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-line p-5">
            <div><h2 class="font-display text-lg font-semibold">Quiz yang Tersedia</h2><p class="mt-1 text-xs text-ink/45">Quiz published yang belum kamu kerjakan.</p></div>
            <a href="<?php echo e(route('student.akademik.quiz.index')); ?>" class="text-sm font-semibold text-teal">Lihat semua</a>
        </div>
        <div class="divide-y divide-line">
            <?php $__empty_1 = true; $__currentLoopData = $quizTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('student.quiz.show', $quiz)); ?>" class="block p-5 transition hover:bg-paper">
                    <div class="flex items-start justify-between gap-4"><div><p class="font-semibold"><?php echo e($quiz->judul); ?></p><p class="mt-1 text-xs text-ink/45"><?php echo e($quiz->pengajaranDosen->kelas->matakuliah->nama_mk ?? '-'); ?> · Kelas <?php echo e($quiz->pengajaranDosen->kelas->kode_kelas ?? '-'); ?></p></div><?php if($quiz->durasi_menit): ?><span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700"><?php echo e($quiz->durasi_menit); ?> menit</span><?php endif; ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-8 text-center text-sm text-ink/50">Tidak ada quiz yang belum dikerjakan.</div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.app-student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\elearning_ar\resources\views/student/dashboard.blade.php ENDPATH**/ ?>