<?php if(isset($chatSidebarClasses) && $chatSidebarClasses->isNotEmpty()): ?>
<div class="ml-9 mt-1 mb-2 space-y-1 border-l border-white/10 pl-3">
  <?php $__currentLoopData = $chatSidebarClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('chat.show', $chatKelas)); ?>"
       class="block px-2 py-1.5 rounded-md text-[12px] text-paper/55 hover:bg-white/5 hover:text-paper transition-colors truncate"
       title="<?php echo e($chatKelas->matakuliah->nama_mk ?? $chatKelas->kode_mk); ?> - Kelas <?php echo e($chatKelas->kode_kelas); ?>">
      <?php echo e($chatKelas->matakuliah->nama_mk ?? $chatKelas->kode_mk); ?>

      <span class="text-paper/30">· <?php echo e($chatKelas->kode_kelas); ?></span>
    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\elearning_ar\resources\views/partials/chat-course-links.blade.php ENDPATH**/ ?>